﻿namespace CoopShopInfos.Models
{
    public enum Unit
    {
        Kilo,
        Litre,
        Pièce
    }
}